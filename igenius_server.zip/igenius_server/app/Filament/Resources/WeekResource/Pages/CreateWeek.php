<?php

namespace App\Filament\Resources\WeekResource\Pages;

use App\Filament\Resources\WeekResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWeek extends CreateRecord
{
    protected static string $resource = WeekResource::class;
}
